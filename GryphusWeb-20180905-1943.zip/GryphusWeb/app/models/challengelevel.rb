class Challengelevel < ApplicationRecord
  # Relaciones entre las tablas
  has_many :challenges
end
