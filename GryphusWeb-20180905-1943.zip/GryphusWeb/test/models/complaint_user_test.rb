require 'test_helper'

class ComplaintUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
